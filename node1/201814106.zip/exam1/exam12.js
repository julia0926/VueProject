function sort(a) {
    a[i].split('').sort().reverse().join('');
}

let a = [ "one", "two", "three", "four", "five"  ];
sort(a);
console.log(a);
