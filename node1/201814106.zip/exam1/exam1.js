function doSomething(a, b, c) {
     let num=Math.max(a,b,c);
     return num;
}

console.log(doSomething(3, 1, 2));
console.log(doSomething(1, 2, 3));
console.log(doSomething(1, 3, 2));
